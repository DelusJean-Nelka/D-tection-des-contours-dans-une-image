# Contour_segmentation_images
Détection des contours et segmentation d'une image en C++ en utilisant la bibliothèque OpenCV 
